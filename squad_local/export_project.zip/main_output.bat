docker build -t cv-junior .
     docker run -p 5000:5000 cv-junior