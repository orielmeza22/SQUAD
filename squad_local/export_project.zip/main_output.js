// src/components/Button.test.js

import React from 'react';
import { render } from '@testing-library/react';
import Button from './Button';

describe('Button component', () => {
  it('should render without crashing', () => {
    const { getByText } = render(<Button />);
    expect(getByText('Click me')).toBeInTheDocument();
  });

  it('should change the text when clicked', () => {
    const mockFunction = jest.fn();
    const { getByText, rerender } = render(
      <Button onClick={mockFunction}>Click me</Button>
    );

    const button = getByText('Click me');
    expect(button).toBeInTheDocument();

    fireEvent.click(button);
    expect(mockFunction).toHaveBeenCalled();
  });
});